# Big Five Result

This is a simple application that submits some data to RecruitBot.

To run the script, run `ruby submit.rb` on the working directory.

This will return a 422 error code since the email field is a unique field.

However, you can change the email to create a new object on RecruitBot.
